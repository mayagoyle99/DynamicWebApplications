module.exports = {
  consumer_key: 'Pczwgc2I9OfY6cKub98ovCUqC',
  consumer_secret: '2yFRFJWgdmiZf3TiesrA7ISQUpbl41kxJ2rFnYPTnVNYtlN3Qi',
  access_token: '1047163919834525697-hPxN7NfHiKs5e8xgo4ZGM5wdB7OBYq',
  access_token_secret: 'cxgjqZYOG82joXKVzDmJr0GcAryhtB4j4ZaWwuMLJcS5M',
  timeout_ms: 60 * 1000, // optional HTTP request timeout to apply to all requests.
  strictSSL: true // optional - requires SSL certificates to be valid.
};
