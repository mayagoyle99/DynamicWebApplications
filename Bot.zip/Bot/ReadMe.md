Hi, welcome to my bot!

This is an informational twitter bot that posts twice every day.

It pulls from two different JSON files and makes sure the topics match each other. Then it will spit out fun facts about different elements!

Enjoy!